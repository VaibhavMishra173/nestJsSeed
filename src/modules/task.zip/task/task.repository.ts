import { Repository } from 'typeorm';
import { Pager, PaginationDto } from '../../dto/pager.dto';
import { CustomRepository } from '../database/typeorm-ex.decorator';
import { TaskDTO, TaskResponseDTO, UpdateTaskDTO } from './task.dto';
import { Task } from './task.entity';

@CustomRepository(Task)
export class TaskRepository extends Repository<Task> {
  async updateTask(updateTaskDto: UpdateTaskDTO, taskId: number) {
    return await this.createQueryBuilder('task').update('task').set({
      title: updateTaskDto.title,
      status: updateTaskDto.status,
      priority: updateTaskDto.priority,
      dueDate: updateTaskDto.dueDate
    }).where('id=:taskId', { taskId }).execute();
  }

  async getTasksOfUser(pagination: PaginationDto, startIndex: number, status: boolean, priority: boolean, dueDate: "ASC" | "DESC", userId: number): Promise<TaskResponseDTO> {
    const totalCount = await this.count();
    const tasks = await this.createQueryBuilder('task')
      .leftJoinAndSelect('user', 'user', 'user.id = task.userId')
      .select(['user.email', 'user.name', 'task.id', 'task.title', 'task.description', 'task.priority', 'task.status', 'task.dueDate'])
      .andWhere('task.priority = :priority', { priority })
      .andWhere('task.status = :status', { status })
      .orderBy('task.dueDate', 'ASC')
      .limit(pagination.limit)
      .offset(startIndex)
      .getMany();



    // const tasks = await this.createQueryBuilder('task')
    //   .select('task')
    //   .from(Task, "task")
    //   .where('task.userId = :userId', { userId: userId })
    //   .andWhere('task.status = :status', { status })
    //   .andWhere('task.priority = :priority', { priority })
    //   .orderBy('task.dueDate', "ASC")
    //   .limit(pagination.limit)
    //   .offset(startIndex)
    //   .getMany();

    const tasksDTORes: TaskDTO[] = [];
    for (const item of tasks) {
      tasksDTORes.push(item);
    }
    const pager = new Pager(totalCount, Number(pagination.page), Number(pagination.limit), startIndex);
    const taskResWithPagination: TaskResponseDTO = new TaskResponseDTO();
    taskResWithPagination.tasks = tasksDTORes;
    taskResWithPagination.pager = pager;
    return taskResWithPagination;
  }

  findTasksOfUser(id: string): Promise<Task[]> {
    return this.createQueryBuilder('task').innerJoin('task.user', 'user').where('user.id = :id', { id }).orderBy('task.status', 'ASC').getMany();
  }
}
