import { Body, Controller, HttpStatus, Param, Post, Query } from '@nestjs/common';
import { Delete, Get, Patch, Req, UseGuards } from "@nestjs/common/decorators";
import { ApiResponse, ApiSecurity, ApiTags } from '@nestjs/swagger';
// import { logger } from '../../config/app-logger.config';
import { PaginationDto } from '../../dto/pager.dto';
import { RequestMetaService } from '../../interceptors/request-meta.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CreateTaskDTO, TaskDTO, TaskFilterDTO, TaskResponseDTO, UpdateTaskDTO } from './task.dto';
import { TaskService } from './task.service';

@Controller('tasks')
@ApiTags('tasks')
@UseGuards(JwtAuthGuard)
export class TaskController {
    constructor(private readonly taskService: TaskService, private readonly requestMetaService: RequestMetaService) { }

    @Post()
    @ApiSecurity('BearerAuthorization')
    @ApiResponse({
        status: HttpStatus.OK,
        type: TaskDTO,
        description: 'TokenDetailsDTO with token details and returns TaskDTO',
    })
    async createTask(@Body() createTaskDto: CreateTaskDTO, @Req() request: Request): Promise<TaskDTO> {
        let requestMeta = await this.requestMetaService.getRequestMeta(request);
        let userId: any = requestMeta.userId;
        return this.taskService.createTask(createTaskDto, userId);
    }

    @Delete("/:taskId")
    @ApiResponse({
        status: HttpStatus.OK,
        description: 'Task deleted successfully',
    })
    async deleteTask(@Param('taskId') taskId: number, @Req() request: Request) {
        return await this.taskService.deleteTask(taskId, request);
    }

    @Patch('/:taskId')
    async updateTask(@Body() updateTaskDto: UpdateTaskDTO, @Param('taskId') taskId: number, @Req() request: Request) {
        return await this.taskService.updateTask(updateTaskDto, taskId, request);
    }
    
    @Get()
    @ApiResponse({
        status: HttpStatus.OK,
        type: TaskResponseDTO,
        description: 'TaskResponseDTO with task & pagination details',
    })
    async getTasksOfUser(@Query() paginationDto: PaginationDto, @Query() taskFilterDTO: TaskFilterDTO, @Req() request: Request): Promise<TaskResponseDTO> {
        if (!paginationDto.limit) {
            paginationDto.limit = 10;
        }
        if (!paginationDto.page) {
            paginationDto.page = 1;
        }
        if (!taskFilterDTO.status) {
            taskFilterDTO.status = false;
        }
        if (!taskFilterDTO.priority) {
            taskFilterDTO.priority = true;
        }
        if (!taskFilterDTO.dueDate) {
            taskFilterDTO.dueDate = 'ASC';
        }
        let requestMeta = await this.requestMetaService.getRequestMeta(request);
        let userId: any = requestMeta.userId;
        return await this.taskService.getTasksOfCurrentUser(paginationDto, taskFilterDTO, userId);
    }
}
