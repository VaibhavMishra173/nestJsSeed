import { ApiProperty, ApiResponseProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsString } from 'class-validator';
import { Pager } from '../../dto/pager.dto';

export class CreateTaskDTO {
  @ApiProperty()
  @IsNotEmpty()
  title: string;

  @ApiProperty()
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  dueDate: string;

  @ApiProperty()
  @IsNotEmpty()
  status: boolean;

  @ApiProperty()
  @IsNotEmpty()
  priority: boolean;
}

export class TaskDTO {
  @ApiResponseProperty()
  id: number;

  @ApiResponseProperty()
  @IsNotEmpty()
  title: string;

  @ApiResponseProperty()
  description: string;

  @ApiResponseProperty()
  @IsNotEmpty()
  @IsDateString()
  dueDate: string;

  @ApiResponseProperty()
  @IsNotEmpty()
  status: boolean;

  @ApiResponseProperty()
  @IsNotEmpty()
  priority: boolean;
}

export class TaskResponseDTO {
  @ApiResponseProperty()
  tasks: TaskDTO[];

  @ApiResponseProperty()
  pager: Pager;
}


export class UpdateTaskDTO {
  @IsString()
  @ApiProperty()
  title: string;
  description: string;
  @IsDateString()
  dueDate: string;
  status: boolean;
  priority: boolean;

}

// export class TaskDeleteDTO {
//   @ApiResponseProperty()
//   id: number;
// }

export class TaskFilterDTO {
  @ApiProperty()
  dueDate: 'ASC' | 'DESC';

  @ApiProperty()
  status: boolean;

  @ApiProperty()
  priority: boolean;
}
