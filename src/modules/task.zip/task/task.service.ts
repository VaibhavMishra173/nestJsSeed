import { Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { logger } from 'src/config/app-logger.config';
import { RequestMeta } from 'src/dto/request-meta.dto';
import { getStartIndex, PaginationDto } from '../../dto/pager.dto';
import { RequestMetaService } from '../../interceptors/request-meta.service';
import { User } from '../user/user.entity';
import { CreateTaskDTO, TaskDTO, TaskFilterDTO, TaskResponseDTO, UpdateTaskDTO } from './task.dto';
import { Task } from './task.entity';
import { TaskRepository } from './task.repository';

@Injectable()
export class TaskService {
  constructor(
    private readonly taskRepository: TaskRepository,
    private readonly requestMetaService: RequestMetaService,
  ) { }

  async createTask(createTaskDto: CreateTaskDTO, user: User): Promise<TaskDTO> {
    let task: Task = new Task();
    task.title = createTaskDto.title;
    task.description = createTaskDto.description;
    task.dueDate = createTaskDto.dueDate;
    task.status = createTaskDto.status;
    task.priority = createTaskDto.priority;
    task.user = user;
    task = await this.taskRepository.save(task);
    logger.info(`New task created: ${task.title}`);
    const { id } = task;
    return { id } as TaskDTO;
  }

  async getTasksOfCurrentUser(paginationDto: PaginationDto, taskFilterDTO: TaskFilterDTO, user: User): Promise<TaskResponseDTO> {
    const startIndex = getStartIndex(paginationDto.page, paginationDto.limit);
    const status = taskFilterDTO.status;
    const priority = taskFilterDTO.priority;
    const dueDate = taskFilterDTO.dueDate;
    let userId = Number(user);
    return this.taskRepository.getTasksOfUser(paginationDto, startIndex, status, priority, dueDate, userId);
  }

  async updateTask(updateTaskDto: UpdateTaskDTO, taskId: number, request: Request) {
    const requestMeta: RequestMeta = await this.requestMetaService.getRequestMeta(request);
    const userEmail = await this.findEmailByTaskId(taskId);
    if (requestMeta.email === userEmail) {
      const id = await this.taskRepository.findBy({id: taskId});
      if (!id) {
        throw new NotFoundException('Task not found');
      }
      return this.taskRepository.updateTask(updateTaskDto, taskId);
    }
    throw new UnauthorizedException('User not Authorised');
  }

  async deleteTask(taskId: number, request: Request) {
    const requestMeta: RequestMeta = await this.requestMetaService.getRequestMeta(request);
    const userEmail = await this.findEmailByTaskId(taskId);
    if (requestMeta.email === userEmail) {
      const id = await this.taskRepository.findBy( {id: taskId} );

      if (!id) {
        throw new NotFoundException('Task not found');
      }
      return this.taskRepository.delete(taskId);
    }
    throw new UnauthorizedException('User not Authorised');
  }

  async findEmailByTaskId(taskId: number) {
    const task = await this.taskRepository.findOneBy( {id: taskId} );

    if (!task) {
      throw new NotFoundException(`Task with ID ${taskId} not found`);
    }
    const user = await task.user;

    if (!user) {
      throw new NotFoundException(`User associated with task with ID ${taskId} not found`);
    }

    return user.email;
  }


}
